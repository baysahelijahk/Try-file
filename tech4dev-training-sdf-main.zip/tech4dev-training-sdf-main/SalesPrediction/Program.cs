﻿//Declaring & Initializing Variables
double ecdSalesPercentage = 0.62;
double companyAnnualSale = 1200000;

//Calculating the East Coast Division Sales Revenue
double ecdSalesRevenue = companyAnnualSale * ecdSalesPercentage;

//Displaying the East Coast Division Sales Revenue
Console.WriteLine("East Coast Sales Divsion Revenue = $" + ecdSalesRevenue);