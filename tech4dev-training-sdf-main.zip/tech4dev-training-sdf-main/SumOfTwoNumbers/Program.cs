﻿int number1 = 62, number2 = 99;

int total = number1 + number2;

Console.WriteLine("Total = " + total);